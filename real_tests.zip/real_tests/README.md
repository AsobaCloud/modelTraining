# Integration Tests (No Smoke)

These tests **execute real code paths**. They do not use "Null" stubs or bypass logic.

What *is* faked:
- **S3 only**: an in-memory `FakeS3` object to avoid hitting AWS during tests.

Everything else is **real**:
- Your data pipeline runs against real on-disk temp files (JSONL/JSON/TXT; PDF if `PyPDF2` is installed).
- Monitoring logic writes/reads real JSON payloads into FakeS3 and is validated for **run-id isolation** and **cleanup** semantics.
- A tiny end-to-end training test executes a success path and asserts the **completion marker is only written on success** (no `atexit`).

## Usage

Install pytest:
```bash
pip install -U pytest
```

Tell the suite where your modules live:
```bash
export SUT_REGEN_PATH=/abs/path/to/regenerate_policy_data.py
export SUT_TRAIN_PATH=/abs/path/to/train_mistral_simple.py
# Optional: if HeartbeatManager lives in a separate file
export SUT_HEARTBEAT_PATH=/abs/path/to/heartbeat_manager.py
```

Run:
```bash
pytest -q /mnt/data/real_tests
```

### Notes
- If `PyPDF2` is installed, the data test also validates PDF extraction (first 2 pages).
- If `PyPDF2` is missing, the test still runs on JSON/JSONL/TXT and asserts **dedupe** and **combined file** outputs.
- The training test does NOT require Transformers; it uses your script's entrypoints and monkeypatches `write_completion_marker()` to verify it's called **exactly once** on success.

If function names differ from what's assumed here, the tests will fail loudly with the missing symbol—tell me your exact names and I’ll align the suite.
