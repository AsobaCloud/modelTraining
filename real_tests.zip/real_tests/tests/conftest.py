
import os, pytest
from tests.helpers import FakeS3, load_module_from_path

@pytest.fixture(scope="session")
def sut_paths():
    regen = os.environ.get("SUT_REGEN_PATH")
    train = os.environ.get("SUT_TRAIN_PATH")
    hb = os.environ.get("SUT_HEARTBEAT_PATH")
    if not regen or not train:
        pytest.skip("Set SUT_REGEN_PATH and SUT_TRAIN_PATH to run integration tests.")
    return {"regen": regen, "train": train, "hb": hb}

@pytest.fixture()
def fake_s3():
    return FakeS3()
