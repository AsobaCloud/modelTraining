
import os, sys, json, importlib.util
from pathlib import Path

class FakeS3:
    """
    In-memory S3 with a subset of boto3 methods used by monitoring code.
    Keys are stored in a dict keyed by 'Bucket/Key' -> bytes
    """
    def __init__(self):
        self.store = {}

    def _k(self, bucket, key):
        return f"{bucket}/{key}"

    def put_object(self, Bucket, Key, Body, ContentType="application/json"):
        k = self._k(Bucket, Key)
        if isinstance(Body, (dict, list)):
            Body = json.dumps(Body).encode("utf-8")
        elif isinstance(Body, str):
            Body = Body.encode("utf-8")
        self.store[k] = Body
        return {"ResponseMetadata": {"HTTPStatusCode": 200}}

    def upload_file(self, Filename, Bucket, Key):
        with open(Filename, "rb") as f:
            body = f.read()
        self.store[self._k(Bucket, Key)] = body
        return {"ResponseMetadata": {"HTTPStatusCode": 200}}

    def get_object(self, Bucket, Key):
        k = self._k(Bucket, Key)
        if k not in self.store:
            raise KeyError(Key)
        return {"Body": self.store[k]}

    def list_objects_v2(self, Bucket, Prefix):
        prefix = f"{Bucket}/{Prefix}"
        keys = [k.split("/", 1)[1] for k in self.store.keys() if k.startswith(prefix)]
        contents = [{"Key": key} for key in keys]
        return {"Contents": contents}

    def delete_object(self, Bucket, Key):
        k = self._k(Bucket, Key)
        self.store.pop(k, None)
        return {"ResponseMetadata": {"HTTPStatusCode": 204}}

    def delete_prefix(self, Bucket, Prefix):
        prefix = f"{Bucket}/{Prefix}"
        to_delete = [k for k in self.store.keys() if k.startswith(prefix)]
        for k in to_delete:
            del self.store[k]

def load_module_from_path(module_name: str, path: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod
