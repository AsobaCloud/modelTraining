
import pytest
from tests.helpers import load_module_from_path

def test_completion_marker_only_on_success(monkeypatch, sut_paths):
    mod = load_module_from_path("train_mistral_simple_user", sut_paths["train"])

    if not hasattr(mod, "write_completion_marker"):
        pytest.skip("write_completion_marker() not found in training script.")

    called = {"count": 0}
    def fake_write_marker():
        called["count"] += 1

    monkeypatch.setattr(mod, "write_completion_marker", fake_write_marker, raising=True)

    # Try common entrypoints: class method or top-level train()
    trained = False
    if hasattr(mod, "MistralTrainer"):
        t = getattr(mod, "MistralTrainer")
        # Create instance with minimal args; bypass heavy deps in your constructor if needed
        try:
            trainer = t(model_name="dummy", s3_bucket="none", s3_prefix="none")
            # Provide a direct success path if available (finish_success/finalize); else monkeypatch any save/upload calls
            if hasattr(trainer, "finish_success"):
                trainer.finish_success()
                trained = True
        except Exception:
            pass

    if not trained and hasattr(mod, "train"):
        try:
            mod.train()
            trained = True
        except Exception:
            pass

    assert trained, "Could not find a recognizable training success path."
    assert called["count"] == 1, "Completion marker should be written exactly once on success."
