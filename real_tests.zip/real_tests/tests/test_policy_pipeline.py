
import json
from pathlib import Path
from tests.helpers import load_module_from_path

def write_jsonl(p, rows):
    with open(p, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def test_policy_pipeline_dedupe_and_output(tmp_path, sut_paths):
    mod = load_module_from_path("regenerate_policy_data", sut_paths["regen"])

    src_root = tmp_path / "src"
    s1 = src_root / "nersa"; s1.mkdir(parents=True, exist_ok=True)
    s2 = src_root / "doe"; s2.mkdir(parents=True, exist_ok=True)

    write_jsonl(s1 / "a.jsonl", [
        {"text": "Policy ABC\nLine1"},
        {"text": "Policy ABC\nLine1"},  # duplicate
        {"text": "Policy DEF"}
    ])

    (s2 / "b.json").write_text(json.dumps([{"text": "Policy DEF"}, {"text": "Unique GHI"}]), encoding="utf-8")
    (s2 / "c.txt").write_text("Plain Text Statute", encoding="utf-8")

    # Patch POLICY_SOURCES to only our local temp dirs
    mod.POLICY_SOURCES = [
        {"name": "nersa", "path": str(s1), "includes": ["*.jsonl"], "excludes": [], "max_files": None},
        {"name": "doe", "path": str(s2), "includes": ["*.json", "*.txt"], "excludes": [], "max_files": None},
    ]

    combined_file, total = mod.download_and_process_policy_data(str(tmp_path))

    texts = []
    with open(combined_file, "r", encoding="utf-8") as f:
        for line in f:
            texts.append(json.loads(line)["text"])

    assert "Policy ABC\nLine1" in texts
    assert "Policy DEF" in texts
    assert "Unique GHI" in texts
    assert "Plain Text Statute" in texts
    assert len(texts) == 4, f"Expected 4 unique entries, got {len(texts)}"
