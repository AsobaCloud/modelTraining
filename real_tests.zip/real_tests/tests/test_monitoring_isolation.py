
import json, pytest
from tests.helpers import load_module_from_path

def _load_hb(sut_paths):
    if sut_paths["hb"]:
        mod = load_module_from_path("heartbeat_manager_user", sut_paths["hb"])
        return getattr(mod, "HeartbeatManager")
    train_mod = load_module_from_path("train_script_for_hb", sut_paths["train"])
    if hasattr(train_mod, "HeartbeatManager"):
        return train_mod.HeartbeatManager
    pytest.skip("HeartbeatManager not found. Set SUT_HEARTBEAT_PATH if it's in a separate file.")

def test_run_id_isolation_and_cleanup(fake_s3, sut_paths):
    HeartbeatManager = _load_hb(sut_paths)
    bucket = "test-bucket"
    base = "monitoring/base"
    run_old = "run-OLD"
    run_new = "run-NEW"

    hb_old = HeartbeatManager(fake_s3, bucket, base, run_old)
    hb_old.start()
    hb_old.mark_error("old failure")

    hb_new = HeartbeatManager(fake_s3, bucket, base, run_new)
    hb_new.start()
    hb_new.update_phase("train", "ok", "step 1/1000")

    key_new_status = f"{base}/runs/{run_new}/status.json"
    obj = fake_s3.get_object(bucket, key_new_status)
    status = json.loads(obj["Body"].decode("utf-8"))
    assert status["state"] in ("train", "training", "ok", "starting")

    with pytest.raises(KeyError):
        fake_s3.get_object(bucket, f"{base}/runs/{run_new}/markers/error.json")

    hb_new.finalize(success=True)
    fake_s3.get_object(bucket, f"{base}/runs/{run_new}/markers/complete.json")
    with pytest.raises(KeyError):
        fake_s3.get_object(bucket, f"{base}/runs/{run_new}/markers/error.json")
